﻿# 01. Create Jekyll Site
------
Problems for in-class lab for the [CSS Advanced](https://softuni.bg/trainings/2427/css-advanced-july-2019) course @ **SoftUni**.

## Tasks:

### Create a Jekyll site - instructions	
	* Download RubyInstaller	
	* Install Ruby
	* Install Jekyll		
	* Create a Jekyll site

### Upload your Jekyll site in Github
	* Create your own account with https://github.com/. If you already have one, use it.
	* Create a Repository
	* Clone the repository in the folder on your computer where your Jekyll site is.
	* Add the files in the local repo and commit it.

* Create a text file and save the link to the Github repository. 
* Upload the file [here](https://softuni.bg/trainings/2427/css-advanced-july-2019#lesson-12420).

